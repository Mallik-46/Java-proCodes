package com.libraryapp.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;

import com.libraryapp.dao.UserRepository;
import com.libraryapp.dao.UserRepositoryImplement;
import com.libraryapp.model.Book;
import com.libraryapp.model.Library;
import com.libraryapp.model.User;

@Service
public class UserServices {

	@Autowired
	Book book;

	@Autowired
	UserRepositoryImplement userRepoImp;

	public List<User> getAllUsers() {
		return userRepoImp.getAllUsers();
	}

	public User getUser(Integer userId) {
		return userRepoImp.getUser(userId);

	}

	public void saveUser(User user) {

		userRepoImp.saveUser(user);
	}

	public String deleteUser(Integer userId) {

		String name = userRepoImp.deleteUser(userId);

		return name;

	}

	public void saveBooks(User user) {

		userRepoImp.saveBooks(user);
	}

	public List<Library> getAllBooks() {

		return userRepoImp.getAllBooks();

	}

	public Library getBook(Integer bookId) {

		return userRepoImp.getBook(bookId);

	}

	public void saveDetails(Integer userId, Integer bookId) {

		Library books = userRepoImp.saveDetails(userId, bookId);
		List<Book> listb = new ArrayList<>();
		User user = userRepoImp.getUser(userId);
		book.setTitle(books.getTitle());
		book.setAuthor(books.getAuthor());
		book.setBookId(books.getLibraryId());
		book.setUserId(user.getUserId());
		book.setReturnDate("31/03/2022");
		listb.add(book);
		book.setUser(user);
		userRepoImp.saveBook(book);
		user.setBook(listb);
		userRepoImp.saveUser(user);

	}

	public void saveBook(Book book) {

		userRepoImp.saveBook(book);
	}

	public String deleteBook(Integer bookId, Integer userId) {

		return userRepoImp.delBook(bookId, userId);
	}

}
