package com.libraryapp.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.libraryapp.model.Book;
import com.libraryapp.model.Library;
import com.libraryapp.model.User;

@Repository
public class UserRepositoryImplement implements UserRepository {

	private EntityManager entityManager;


	@Autowired
	public UserRepositoryImplement(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}

	@Override
	@Transactional
	public List<User> getAllUsers() {
		Session session = entityManager.unwrap(Session.class);
		return session.createQuery("from User", User.class).list();
	}

	@Override
	@Transactional
	public User getUser(Integer userId) {
		Session session = entityManager.unwrap(Session.class);
		return session.get(User.class, userId);
	}

	@Override
	@Transactional
	public void saveUser(User user) {
		Session session = entityManager.unwrap(Session.class);
		session.saveOrUpdate(user);

	}

	@Override
	@Transactional
	public String deleteUser(Integer userId) {
		Session session = entityManager.unwrap(Session.class);
		User user = session.get(User.class, userId);
		String name = user.getName();
		session.delete(user);
		return name;
	}

	@Override
	@Transactional
	public void saveBooks(User user) {
		Session session = entityManager.unwrap(Session.class);
		session.saveOrUpdate(user);
	}

	@Override
	@Transactional
	public List<Library> getAllBooks() {
		Session session = entityManager.unwrap(Session.class);
		return session.createQuery("from Library", Library.class).list();

	}

	@Override
	@Transactional
	public Library getBook(Integer bookId) {
		Session session = entityManager.unwrap(Session.class);
		return session.get(Library.class, bookId);
	}

	@Override
	@Transactional
	public Library saveDetails(Integer userId, Integer bookId) {

		Session session = entityManager.unwrap(Session.class);
	 
		User user = session.get(User.class, userId);
		Library books = session.get(Library.class, bookId);
		
		return books;
	 
	}

	@Override
	@Transactional
	public void saveBook(Book book) {

		Session session = entityManager.unwrap(Session.class);
		session.save(book);

	}

	@Override
	@Transactional
	public String delBook(Integer bookId, Integer userId) {
		Session session = entityManager.unwrap(Session.class);
		Book book = session.get(Book.class, bookId);
		String tittle = book.getTitle();
		Query query = session.createQuery("delete from Book where bookid=:x");
		query.setParameter("x", bookId);
		query.executeUpdate();
		return tittle;

	}

}
