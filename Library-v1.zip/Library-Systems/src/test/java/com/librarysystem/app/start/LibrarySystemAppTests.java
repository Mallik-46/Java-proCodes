package com.librarysystem.app.start;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrarySystemAppTests {

	@Test
	void contextLoads() {
	}

}
